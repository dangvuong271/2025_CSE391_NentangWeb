import React from "react";

const BookList = ({ books, deleteBook, editBook }) => {
  if (books.length === 0) return <p>Chưa có sách nào.</p>;

  return (
    <table border="1" cellPadding="8" cellSpacing="0" style={{ width: "100%" }}>
      <thead>
        <tr>
          <th>Tên sách</th>
          <th>Tác giả</th>
          <th>Hành động</th>
        </tr>
      </thead>
      <tbody>
        {books.map(({ id, title, author }) => (
          <tr key={id}>
            <td>{title}</td>
            <td>{author}</td>
            <td>
              <button onClick={() => editBook({ id, title, author })}>Sửa</button>
              <button onClick={() => deleteBook(id)} style={{ marginLeft: "8px" }}>
                Xóa
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default BookList;