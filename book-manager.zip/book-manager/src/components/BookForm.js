import React, { useState, useEffect } from "react";

const BookForm = ({ addBook, editingBook, updateBook }) => {
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");

  useEffect(() => {
    if (editingBook) {
      setTitle(editingBook.title);
      setAuthor(editingBook.author);
    } else {
      setTitle("");
      setAuthor("");
    }
  }, [editingBook]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || !author.trim()) return;

    if (editingBook) {
      updateBook({ ...editingBook, title, author });
    } else {
      addBook({ title, author });
    }

    setTitle("");
    setAuthor("");
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "20px" }}>
      <input
        type="text"
        placeholder="Tên sách"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        style={{ marginRight: "10px" }}
      />
      <input
        type="text"
        placeholder="Tác giả"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        style={{ marginRight: "10px" }}
      />
      <button type="submit">{editingBook ? "Cập nhật" : "Thêm sách"}</button>
    </form>
  );
};

export default BookForm;