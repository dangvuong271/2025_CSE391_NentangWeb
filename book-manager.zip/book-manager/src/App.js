import React, { useState, useEffect } from "react";
import BookList from "./components/BookList";
import BookForm from "./components/BookForm";

function App() {
  const [books, setBooks] = useState(() => {
    const savedBooks = localStorage.getItem("books");
    return savedBooks ? JSON.parse(savedBooks) : [];
  });

  const [editingBook, setEditingBook] = useState(null);

  useEffect(() => {
    localStorage.setItem("books", JSON.stringify(books));
  }, [books]);

  const addBook = (book) => {
    setBooks([...books, { ...book, id: Date.now() }]);
  };

  const updateBook = (updatedBook) => {
    setBooks(books.map(book => book.id === updatedBook.id ? updatedBook : book));
    setEditingBook(null);
  };

  const deleteBook = (id) => {
    setBooks(books.filter(book => book.id !== id));
  };

  const editBook = (book) => {
    setEditingBook(book);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Ứng dụng Quản Lý Sách</h1>
      <BookForm addBook={addBook} editingBook={editingBook} updateBook={updateBook} />
      <BookList books={books} deleteBook={deleteBook} editBook={editBook} />
    </div>
  );
}

export default App;